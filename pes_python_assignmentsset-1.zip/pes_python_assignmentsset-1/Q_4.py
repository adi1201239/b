a = int(input("Enter any number: "))
# prime number is always greater than 1
if a > 1:
    for i in range(2, a):
        if (a % i) == 0:
            print(a, "is not a prime number")
            break
    else:
        print(a, "is a prime number")

# if the entered number is less than or equal to 1
# then it is not prime number
else:
    print(a, "is not a prime number")