a = int(input("Enter a number "))

if a%2 == 0:
    print("The given number is Even")
else:
    print("The gievn number is odd")