a=450
b=150
c=0

c=a&b
print ("a AND b: ",c)

c=a|b
print ("a OR b: ", c)

c=a^b
print ("a XOR b : ",c)

c=~a
print ("1's compliment of a: ",c)

c=a<<2
print ("Left shift of a : ",c)

c=b>>2
print ("Right shit of b : ",c)
