a=float(input("Enter the a : "))
b=float(input("Enter the b : "))

a +=b
print ("Value of a after adding b: ",a)

a -=b
print ("Value of a after subtracting b : ",a)

a /=b
print ("Value of a after division by b : ",a)

a *=b
print ("Value of a after multiplying b : ",a)

a **=b
print ("Value of exponent : ",a)

a //=b
print ("Value of floor div b : ",a)