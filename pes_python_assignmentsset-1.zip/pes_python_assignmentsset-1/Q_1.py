a = 40;
b = 10;

print("Addition of two number", a+b)
print("Subtraction of two number", a-b)
print("Multiplication of two number", a*b)
print("Division of two number", a/b)