a=(4+3j)
b=(3-7j)

print("Addition of two complex numbers : ", a+b)
print("Subtraction of two complex numbers : ", a-b)
print("Multiplication of two complex numbers : ", a*b)
print("Division of two complex numbers : ", a/b)
