
import sys
print "First number is", sys.argv[1]
print "Second number is", sys.argv[2]
print "Third number is", sys.argv[3]
print "The biggest of three numbers is", max(sys.argv[1], sys.argv[2], sys.argv[3])






